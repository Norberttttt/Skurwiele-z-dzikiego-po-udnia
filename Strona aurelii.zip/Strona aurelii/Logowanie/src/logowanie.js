export class logowanie{
   constructors(Login,Haslo) {
       this.Login = Login;
       this.Haslo = Haslo;       
   }   
}