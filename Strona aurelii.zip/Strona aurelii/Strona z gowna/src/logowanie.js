export class Stronagłówna{
   constructors(Login,Haslo) {
       this.Login = Login;
       this.Haslo = Haslo;       
   }   
}