import { logowanie } from './logowanie';

export class Applogowanie {
 constructor() {
     this.heading = 'Strona główna';
     this.urzytkownicy = [];
     this.urzytkownikLogin = '';
     this.urzytkownikHaslo = '';
     this.urzytkownikEmail = '';
     
     }
   
  addurzytkownik() {
      if(this.urzytkownikLogin && this.urzytkownikHaslo && this.urzytkownikEmail) {
          this.urzytkownicy.push(new urzytkownik(this.urzytkownikLogin, this.urzytkownikHaslo, this.urzytkownikEmail));
          //czyste pole
          this.urzytkownikLogin = '';
          this.urzytkownikHaslo = ''; 
          this.urzytkownikEmail = '';         
      }
  }

 removeurzytkownik(urzytkownik) {
     let index = this.customers.indexOf(urzytkownik);
     if(index !== -1) {
         this.urzytkownicy.splice(index, 1);
     }
 }


}