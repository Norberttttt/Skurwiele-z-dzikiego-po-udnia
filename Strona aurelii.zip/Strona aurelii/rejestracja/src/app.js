import { rejestracja } from './logowanie';

export class Apprejestracja {
 constructor() {
     this.heading = 'Rejestracja';
     this.urzytkownicy = [];
     this.urzytkownikNazwisko = '';
     this.urzytkownikImie = '';
     this.urzytkownikHaslo = '';
     this.urzytkownikHaslo1 = '';
     this.urzytkownikEmail = '';     
     }
   
  addurzytkownik() {
      if(this.urzytkownikImie && this.urzytkownikNazwisko && this.urzytkownikHaslo && this.urzytkownikEmail && this.urzytkownikHaslo1)  {
          this.urzytkownicy.push(new urzytkownik(this.urzytkownikImie,this.urzytkownikNazwisko, this.urzytkownikHaslo, this.urzytkownikEmail ,this.urzytkownikHaslo1));
          //czyste pole
          this.urzytkownikImie = '';
          this.urzytkownikNazwisko = '';
          this.urzytkownikHaslo = ''; 
          this.urzytkownikEmail = '';   
          this.urzytkownikHaslo1 = '';       
      }
  }

 removeurzytkownik(urzytkownik) {
     let index = this.customers.indexOf(urzytkownik);
     if(index !== -1) {
         this.urzytkownicy.splice(index, 1);
     }
 }


}