export class rejestracja{
    constructors(Haslo,Email,Imie,Nazwisko) {
        this.Nazwisko = Nazwisko;
        this.Imie = Imie;
        this.Email = Email;
        this.Haslo = Haslo;
        this.Haslo1 = Haslo1;
    }   
 }